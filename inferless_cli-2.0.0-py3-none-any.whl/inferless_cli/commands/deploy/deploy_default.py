import typer


# `deploy` command group
deploy_app = typer.Typer(help="Deploy models to the Inferless server.")

@deploy_app.callback()
def deploy_callback():
    """
    Deploy a model to the Inferless server.
    """
    typer.echo("Use this command to deploy your model to the Inferless server. See options for details.")

# `deploy` common options
@deploy_app.command("model", help="Deploy a model to the Inferless server." , no_args_is_help=True)
def deploy_model(
    gpu: str = typer.Option(..., "--gpu", help="Denotes the machine type (A10/A100/T4)."),
    region: str = typer.Option(None, "--region", help="Inferless region. Defaults to Inferless default region."),
    beta: bool = typer.Option(False, "--beta", help="Deploys the model with v2 endpoints."),
    fractional: bool = typer.Option(False, "--fractional", help="Use fractional machine type (default: dedicated)."),
    runtime: str = typer.Option(None, "--runtime", help="Runtime name or file location. Defaults to Inferless runtime."),
    volume: str = typer.Option(..., "--volume", help="Volume for storing weights."),
    envs: str = typer.Option(None, "--envs", help="Key-value pairs for model environment variables."),
    inference_timeout: int = typer.Option(None, "--inference-timeout", help="Inference timeout in seconds."),
    scale_down_timeout: int = typer.Option(None, "--scale-down-timeout", help="Scale down timeout in seconds."),
    container_concurrency: int = typer.Option(None, "--container-concurrency", help="Container concurrency level."),
    secrets: str = typer.Option(None, "--secrets", help="Secret name to attach to the deployment."),
    runtime_version: str = typer.Option(None, "--runtimeversion", help="Runtime version (default: latest)."),
    all_yes: bool = typer.Option(False, "--all-yes", help="Skip prompts and confirm all options."),
):
    """
    Deploy the model with the specified configuration.
    """
    typer.echo(
        f"Deploying model with GPU: {gpu}, Region: {region}, Beta: {beta}, Fractional: {fractional}, "
        f"Runtime: {runtime}, Volume: {volume}, Envs: {envs}, Inference Timeout: {inference_timeout}, "
        f"Scale Down Timeout: {scale_down_timeout}, Container Concurrency: {container_concurrency}, "
        f"Secrets: {secrets}, Runtime Version: {runtime_version}, All Yes: {all_yes}"
    )



@deploy_app.command("redeploy")
def model_redeploy():
    """
    Redeploy the model with updated configuration.
    """
    typer.echo("Redeploying the model with the updated configuration.")

@deploy_app.command("patch" ,no_args_is_help=True)
def model_patch(
    model_id: str = typer.Argument(..., help="Model ID to patch."),
    gpu: str = typer.Option(None, "--gpu", help="Denotes the machine type (A10/A100/T4)."),
    region: str = typer.Option(None, "--region", help="Inferless region. Defaults to Inferless default region."),
    beta: bool = typer.Option(False, "--beta", help="Deploys the model with v2 endpoints."),
    fractional: bool = typer.Option(False, "--fractional", help="Use fractional machine type (default: dedicated)."),
    volume: str = typer.Option(None, "--volume", help="Volume for storing weights."),
    envs: str = typer.Option(None, "--envs", help="Key-value pairs for model environment variables."),
    inference_timeout: int = typer.Option(None, "--inference-timeout", help="Inference timeout in seconds."),
    scale_down_timeout: int = typer.Option(None, "--scale-down-timeout", help="Scale down timeout in seconds."),
    container_concurrency: int = typer.Option(None, "--container-concurrency", help="Container concurrency level."),
    runtime_version: str = typer.Option(None, "--runtimeversion", help="Runtime version (default: latest)."),
):
    """
    Patch an existing model with updated configurations.
    """
    typer.echo(
        f"Patching model {model_id} with GPU: {gpu}, Region: {region}, Beta: {beta}, Fractional: {fractional}, "
        f"Volume: {volume}, Envs: {envs}, Inference Timeout: {inference_timeout}, "
        f"Scale Down Timeout: {scale_down_timeout}, Container Concurrency: {container_concurrency}, "
        f"Runtime Version: {runtime_version}"
    )

