from .main import app

app(prog_name="inferless")
