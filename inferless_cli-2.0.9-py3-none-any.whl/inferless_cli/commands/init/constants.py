ACCOUNT_NOT_FOUND_MSG = (
    "No connected Github account found. Please connect your Github account first."
)
PROCESSING = "processing..."
